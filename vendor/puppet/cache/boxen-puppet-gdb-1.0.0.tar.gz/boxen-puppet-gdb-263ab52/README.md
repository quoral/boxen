# GDB Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-gdb.png?branch=master)](https://travis-ci.org/boxen/puppet-gdb)

## Usage

```puppet
include gdb
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `stdlib`

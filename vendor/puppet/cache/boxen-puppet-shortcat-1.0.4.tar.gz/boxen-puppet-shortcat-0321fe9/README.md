#Shortcat - Killing mice, one at a time.

[![Build Status](https://travis-ci.org/boxen/puppet-shortcat.png)](https://travis-ci.org/boxen/puppet-shortcat)

Installs [Shortcat](http://shortcatapp.com/).

## Usage

```puppet
include shortcat
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
